create
    definer = root@localhost procedure arrive_remove(in id int)
begin
    start transaction;
    delete from arrive where id_arrive = id;
    commit;
end;

