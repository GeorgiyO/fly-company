create
    definer = root@localhost procedure planes_all()
select *
from planes;

