create
    definer = root@localhost procedure class_get_all()
select *
from class;

