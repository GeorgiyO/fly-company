create
    definer = root@localhost procedure planes_update(in _id int, in _description varchar(250))
begin
    start transaction;
    update planes set description = _description where id = _id;
    select * from planes where id = _id;
    commit;
end;

