create
    definer = root@localhost procedure worker_add(in fio varchar(45), in tel varchar(10))
begin
    start transaction;
    insert into worker (fio_worker, tel_worker)
    values (fio, tel);
    select * from worker where id_worker = last_insert_id();
    commit;
end;

