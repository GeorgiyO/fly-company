create
    definer = root@localhost procedure fly_remove(in id int)
begin
    start transaction;
    delete from fly where id_fly = id;
    commit;
end;

