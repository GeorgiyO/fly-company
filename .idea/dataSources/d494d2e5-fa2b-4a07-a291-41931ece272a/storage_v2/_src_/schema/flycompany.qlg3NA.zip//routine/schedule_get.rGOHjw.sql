create
    definer = root@localhost procedure schedule_get(in _id int)
select *
from schedule
where id = _id;

