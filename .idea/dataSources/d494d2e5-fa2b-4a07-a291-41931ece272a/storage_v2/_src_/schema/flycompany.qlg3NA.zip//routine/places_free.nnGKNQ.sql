create
    definer = root@localhost procedure places_free()
select * from places where free > 0;

