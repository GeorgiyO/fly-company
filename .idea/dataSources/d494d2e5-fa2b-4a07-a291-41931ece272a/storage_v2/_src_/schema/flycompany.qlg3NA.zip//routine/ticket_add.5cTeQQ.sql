create
    definer = root@localhost procedure ticket_add(in number varchar(10), in price decimal(5, 2), in cash int,
                                                  in plan int)
begin
    start transaction;
    insert into ticket (number_ticket, price_ticket, id_cash, id_plan)
    values (number, price, cash, plan);
    select * from ticket where id_ticket = last_insert_id();
    commit;
end;

