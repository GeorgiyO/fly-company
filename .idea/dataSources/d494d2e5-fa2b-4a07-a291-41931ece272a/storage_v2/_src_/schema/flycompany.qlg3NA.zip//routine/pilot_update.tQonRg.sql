create
    definer = root@localhost procedure pilot_update(in fio varchar(45), in tel varchar(10), in plan int, in id int)
begin
    start transaction;
    update pilot
    set fio_pilot = fio,
        tel_pilot = tel,
        id_plan   = plan
    where id_pilot = id;
    select * from pilot where id_pilot = id;
    commit;
end;

