create
    definer = root@localhost procedure plan_remove(in id int)
begin
    start transaction;
    delete from plan where id_plan = id;
    commit;
end;

