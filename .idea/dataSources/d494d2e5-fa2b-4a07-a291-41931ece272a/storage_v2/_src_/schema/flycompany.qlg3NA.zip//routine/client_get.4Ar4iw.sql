create
    definer = root@localhost procedure client_get(in id int)
select *
from client
where id_client = id;

