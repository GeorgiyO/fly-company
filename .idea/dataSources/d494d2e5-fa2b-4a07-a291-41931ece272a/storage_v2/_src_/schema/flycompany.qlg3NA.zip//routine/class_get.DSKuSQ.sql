create
    definer = root@localhost procedure class_get(in id int)
select *
from class
where id_class = id;

