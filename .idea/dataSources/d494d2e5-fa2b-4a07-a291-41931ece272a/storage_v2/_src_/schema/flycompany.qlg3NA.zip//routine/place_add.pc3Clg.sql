create
    definer = root@localhost procedure place_add(in class int, in number varchar(4))
begin
    start transaction;
    insert into place (id_class, number_place)
    values (class, number);
    select * from place where id_place = last_insert_id();
    commit;
end;

