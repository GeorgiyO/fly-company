create
    definer = root@localhost procedure plan_update(in number varchar(10), in kind varchar(10), in worker int,
                                                   in fly int, in id int)
begin
    start transaction;
    update plan
    set number_plan = number,
        kind_plan   = kind,
        id_worker   = worker,
        id_fly      = fly
    where id_plan = id;
    select * from plan where id_plan = id;
    commit;
end;

