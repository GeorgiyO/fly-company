create
    definer = root@localhost procedure arrive_get(in id int)
select *
from arrive
where id_arrive = id;

