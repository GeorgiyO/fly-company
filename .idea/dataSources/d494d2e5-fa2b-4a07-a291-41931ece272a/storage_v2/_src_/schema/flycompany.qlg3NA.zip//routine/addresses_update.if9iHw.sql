create
    definer = root@localhost procedure addresses_update(in _id int, in _value varchar(250))
begin
    start transaction;
    insert into addresses (value)
    values (_value);
    select * from addresses where id = _id;
    commit;
end;

