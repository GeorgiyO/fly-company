create
    definer = root@localhost procedure passengers_update(in _id int, in _first_name varchar(250),
                                                         in _second_name varchar(250), in _patronymic varchar(250),
                                                         in _doc_type varchar(250), in _doc_number varchar(250))
begin
    start transaction;
    update passengers
    set first_name  = _first_name,
        second_name = _second_name,
        patronymic  = _patronymic,
        doc_type    = _doc_type,
        doc_number  = _doc_number
    where id = _id;
    select * from passengers where id = _id;
    commit;
end;

