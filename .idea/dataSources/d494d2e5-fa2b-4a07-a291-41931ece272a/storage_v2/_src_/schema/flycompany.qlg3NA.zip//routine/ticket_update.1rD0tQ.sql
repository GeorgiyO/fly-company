create
    definer = root@localhost procedure ticket_update(in number varchar(10), in price decimal(5, 2), in cash int,
                                                     in plan int, in id int)
begin
    start transaction;
    update ticket
    set number_ticket = number,
        price_ticket  = price,
        id_cash       = cash,
        id_plan       = plan
    where id_ticket = id;
    select * from ticket where id_ticket = id;
    commit;
end;

