create
    definer = root@localhost procedure pilot_get(in id int)
select *
from pilot
where id_pilot = id;

