create
    definer = root@localhost procedure addresses_all()
select *
from addresses;

