create
    definer = root@localhost procedure pilot_add(in fio varchar(45), in tel varchar(10), in plan int)
begin
    start transaction;
    insert into pilot (fio_pilot, tel_pilot, id_plan)
    values (fio, tel, plan);
    select * from pilot where id_pilot = last_insert_id();
    commit;
end;

