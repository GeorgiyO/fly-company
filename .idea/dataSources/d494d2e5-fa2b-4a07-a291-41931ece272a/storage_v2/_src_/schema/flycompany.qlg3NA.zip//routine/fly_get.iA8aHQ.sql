create
    definer = root@localhost procedure fly_get(in id int)
select *
from fly
where id_fly = id;

