create
    definer = root@localhost procedure class_add(in name varchar(10), in plan int)
begin
    start transaction;
    insert into class (name_class, id_plan)
    values (name, plan);
    select * from class where id_class = last_insert_id();
    commit;
end;

