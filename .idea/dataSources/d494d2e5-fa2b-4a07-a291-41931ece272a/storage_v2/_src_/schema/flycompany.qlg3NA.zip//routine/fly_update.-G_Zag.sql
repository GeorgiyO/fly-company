create
    definer = root@localhost procedure fly_update(in number varchar(10), in _date date, in arrive int, in live int,
                                                  in id int)
begin
    start transaction;
    update fly
    set number_fly = number,
        date_fly   = _date,
        id_arrive  = arrive,
        id_live    = live
    where id_fly = id;
    select * from fly where id_fly = id;
    commit;
end;

