create
    definer = root@localhost procedure passengers_all()
select *
from passengers;

