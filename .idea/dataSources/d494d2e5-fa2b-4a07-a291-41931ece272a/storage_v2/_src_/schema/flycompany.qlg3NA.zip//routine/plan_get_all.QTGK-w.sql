create
    definer = root@localhost procedure plan_get_all()
select *
from plan;

