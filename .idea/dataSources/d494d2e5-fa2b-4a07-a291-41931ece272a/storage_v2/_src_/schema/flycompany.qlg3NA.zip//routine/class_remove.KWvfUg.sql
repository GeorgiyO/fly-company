create
    definer = root@localhost procedure class_remove(in id int)
begin
    start transaction;
    delete from class where id_class = id;
    commit;
end;

