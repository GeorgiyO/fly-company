create
    definer = root@localhost procedure live_get_all()
select *
from live;

