create
    definer = root@localhost procedure offers_remove(in _id int)
delete
from offers
where id = _id;

