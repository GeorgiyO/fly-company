create
    definer = root@localhost procedure cash_get_all()
select *
from cash;

