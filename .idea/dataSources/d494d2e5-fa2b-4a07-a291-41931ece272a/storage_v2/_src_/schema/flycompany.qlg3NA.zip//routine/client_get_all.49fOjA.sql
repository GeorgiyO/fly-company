create
    definer = root@localhost procedure client_get_all()
select *
from client;

