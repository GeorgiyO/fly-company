create
    definer = root@localhost procedure cash_add(in number varchar(45))
begin
    start transaction;
    insert into cash (number_cash)
    values (number);
    select * from cash where id_cash = last_insert_id();
    commit;
end;

