create
    definer = root@localhost procedure planes_get(in _id int)
select *
from planes
where id = _id;

