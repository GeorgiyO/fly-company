create
    definer = root@localhost procedure schedule_all()
select *
from schedule;

