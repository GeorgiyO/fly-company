create
    definer = root@localhost procedure cash_update(in number varchar(45), in id int)
begin
    start transaction;
    update cash
    set number_cash = number
    where id_cash = id;
    select * from cash where id_cash = id;
    commit;
end;

