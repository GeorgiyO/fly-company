create
    definer = root@localhost procedure users_remove(in _id int)
delete
from users
where id = _id;

