create
    definer = root@localhost procedure planes_add(in _description varchar(250))
begin
    start transaction;
    insert into planes (description)
    values (_description);
    select * from planes where id = last_insert_id();
    commit;
end;

