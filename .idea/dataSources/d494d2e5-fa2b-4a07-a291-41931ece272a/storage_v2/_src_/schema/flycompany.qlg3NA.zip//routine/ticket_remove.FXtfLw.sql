create
    definer = root@localhost procedure ticket_remove(in id int)
begin
    start transaction;
    delete from ticket where id_ticket = id;
    commit;
end;

