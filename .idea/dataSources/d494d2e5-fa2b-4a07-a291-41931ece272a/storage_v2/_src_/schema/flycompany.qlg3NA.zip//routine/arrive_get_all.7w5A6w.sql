create
    definer = root@localhost procedure arrive_get_all()
select *
from arrive;

