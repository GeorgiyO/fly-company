create
    definer = root@localhost procedure offers_all()
select *
from offers;

