create
    definer = root@localhost procedure worker_get_all()
select *
from worker;

