create
    definer = root@localhost procedure client_update(in fio varchar(45), in password varchar(45), in ticket int,
                                                     in cash int, in id int)
begin
    start transaction;
    update client
    set fio_client      = fio,
        password_client = password,
        id_ticket       = ticket,
        id_cash         = cash
    where id_client = id;
    select * from client where id_client = id;
    commit;
end;

