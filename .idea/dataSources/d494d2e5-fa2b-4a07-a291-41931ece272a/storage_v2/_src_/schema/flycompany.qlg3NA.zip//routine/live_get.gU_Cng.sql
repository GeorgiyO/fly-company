create
    definer = root@localhost procedure live_get(in id int)
select *
from live
where id_live = id;

