create
    definer = root@localhost procedure arrive_update(in name varchar(30), in address varchar(45), in id int)
begin
    start transaction;
    update arrive
    set name_arrive    = name,
        address_arrive = address
    where id_arrive = id;
    select * from arrive where id_arrive = id;
    commit;
end;

