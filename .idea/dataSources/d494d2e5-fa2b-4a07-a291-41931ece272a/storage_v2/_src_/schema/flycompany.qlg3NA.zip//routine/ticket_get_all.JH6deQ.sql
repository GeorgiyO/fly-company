create
    definer = root@localhost procedure ticket_get_all()
select *
from ticket;

