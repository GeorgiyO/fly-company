create
    definer = root@localhost procedure worker_remove(in id int)
begin
    start transaction;
    delete from worker where id_worker = id;
    commit;
end;

