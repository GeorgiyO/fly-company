create
    definer = root@localhost procedure cashiers_add(in _login varchar(250), in _password varchar(250))
begin
    start transaction;
    insert into users (login, password, role_id)
    values (_login, _password, (select id from roles where type = 'CASHIER'));
    select * from users where id = last_insert_id();
    commit;
end;

