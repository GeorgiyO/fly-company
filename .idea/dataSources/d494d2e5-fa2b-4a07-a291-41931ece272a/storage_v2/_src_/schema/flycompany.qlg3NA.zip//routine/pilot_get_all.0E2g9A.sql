create
    definer = root@localhost procedure pilot_get_all()
select *
from pilot;

