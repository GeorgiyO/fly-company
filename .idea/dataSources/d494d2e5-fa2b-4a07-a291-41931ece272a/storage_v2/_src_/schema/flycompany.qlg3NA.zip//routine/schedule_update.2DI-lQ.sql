create
    definer = root@localhost procedure schedule_update(in _id int, in _date datetime, in _price decimal,
                                                       in _plane_id int, in _from_addr_id int, in _to_addr_id int)
begin
    start transaction;
    update schedule
    set date         = _date,
        price        = _price,
        plane_id     = _plane_id,
        from_addr_id = _from_addr_id,
        to_addr_id   = _to_addr_id
    where id = _id;
    select * from schedule where id = _id;
    commit;
end;

