create
    definer = root@localhost procedure addresses_get(in _id int)
select *
from addresses
where id = _id;

