create
    definer = root@localhost procedure offers_get(in _id int)
select *
from offers
where id = _id;

