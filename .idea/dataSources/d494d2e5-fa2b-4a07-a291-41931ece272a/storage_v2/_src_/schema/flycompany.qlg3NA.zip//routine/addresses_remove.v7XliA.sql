create
    definer = root@localhost procedure addresses_remove(in _id int)
delete
from addresses
where id = _id;

