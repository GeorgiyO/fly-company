create
    definer = root@localhost procedure planes_remove(in _id int)
delete
from planes
where id = _id;

