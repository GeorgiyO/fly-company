create
    definer = root@localhost procedure ticket_get(in id int)
select *
from ticket
where id_ticket = id;

