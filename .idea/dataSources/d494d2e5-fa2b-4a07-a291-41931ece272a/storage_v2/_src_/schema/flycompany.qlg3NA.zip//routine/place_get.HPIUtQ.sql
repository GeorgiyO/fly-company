create
    definer = root@localhost procedure place_get(in id int)
select *
from place
where id_place = id;

