create
    definer = root@localhost procedure addresses_add(in _value varchar(250))
begin
    start transaction;
    insert into addresses (value)
    values (_value);
    select * from addresses where id = last_insert_id();
    commit;
end;

