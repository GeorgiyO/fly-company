create
    definer = root@localhost procedure client_add(in fio varchar(45), in password varchar(45), in ticket int,
                                                  in cash int)
begin
    start transaction;
    insert into client (fio_client, password_client, id_ticket, id_cash)
    values (fio, password, ticket, cash);
    select * from client where id_client = last_insert_id();
    commit;
end;

