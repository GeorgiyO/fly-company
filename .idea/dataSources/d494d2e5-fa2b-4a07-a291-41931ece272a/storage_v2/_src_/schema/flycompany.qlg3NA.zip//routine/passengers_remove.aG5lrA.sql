create
    definer = root@localhost procedure passengers_remove(in _id int)
delete
from passengers
where id = _id;

