create
    definer = root@localhost procedure place_remove(in id int)
begin
    start transaction;
    delete from place where id_place = id;
    commit;
end;

