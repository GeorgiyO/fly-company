create
    definer = root@localhost procedure places_get(in _id int)
select *
from places
where id = _id;

