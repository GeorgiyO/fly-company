create
    definer = root@localhost procedure live_add(in name varchar(30), in address varchar(45))
begin
    start transaction;
    insert into live (name_live, address_live)
    values (name, address);
    select * from live where id_live = last_insert_id();
    commit;
end;

