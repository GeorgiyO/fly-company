create
    definer = root@localhost procedure arrive_add(in name varchar(30), in address varchar(45))
begin
    start transaction;
    insert into arrive (name_arrive, address_arrive)
    values (name, address);
    select * from arrive where id_arrive = last_insert_id();
    commit;
end;

