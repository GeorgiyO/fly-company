create
    definer = root@localhost procedure places_take(in _id int)
begin
    start transaction;
    if ((select free from places where id = _id) > 0) then
        update places
        set free = free - 1
        where id = _id;
    end if;
    select * from places where id = _id;
    commit;
end;

