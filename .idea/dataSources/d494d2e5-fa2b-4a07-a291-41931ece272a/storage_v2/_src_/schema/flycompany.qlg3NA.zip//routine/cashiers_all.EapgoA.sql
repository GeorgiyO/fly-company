create
    definer = root@localhost procedure cashiers_all()
select u.id, u.login, u.password, r.type
from users u
         join roles r on r.id = u.role_id
where r.type = 'CASHIER';

