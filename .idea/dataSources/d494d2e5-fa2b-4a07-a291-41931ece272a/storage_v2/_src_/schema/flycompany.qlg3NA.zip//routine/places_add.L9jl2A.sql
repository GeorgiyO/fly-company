create
    definer = root@localhost procedure places_add(in _total int, in _schedule_id int)
begin
    start transaction;
    insert into places (total, free, schedule_id)
    values (_total, _total, _schedule_id);
    select * from places where id = last_insert_id();
    commit;
end;

