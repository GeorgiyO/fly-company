create
    definer = root@localhost procedure passengers_add(in _first_name varchar(250), in _second_name varchar(250),
                                                      in _patronymic varchar(250), in _doc_type varchar(250),
                                                      in _doc_number varchar(250))
begin
    start transaction;
    insert into passengers (first_name, second_name, patronymic, doc_type, doc_number)
    values (_first_name, _second_name, _patronymic, _doc_type, _doc_number);
    select * from passengers where id = last_insert_id();
    commit;
end;

