create
    definer = root@localhost procedure passengers_get(in _id int)
select *
from passengers
where id = _id;

