create
    definer = root@localhost procedure worker_update(in fio varchar(45), in tel varchar(10), in id int)
begin
    start transaction;
    update worker
    set fio_worker = fio,
        tel_worker = tel
    where id_worker = id;
    select * from worker where id_worker = id;
    commit;
end;

