create
    definer = root@localhost procedure plan_get(in id int)
select *
from plan
where id_plan = id;

