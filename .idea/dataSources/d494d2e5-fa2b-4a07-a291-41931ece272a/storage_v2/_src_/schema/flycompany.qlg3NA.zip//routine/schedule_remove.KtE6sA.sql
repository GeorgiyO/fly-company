create
    definer = root@localhost procedure schedule_remove(in _id int)
delete
from schedule
where id = _id;

