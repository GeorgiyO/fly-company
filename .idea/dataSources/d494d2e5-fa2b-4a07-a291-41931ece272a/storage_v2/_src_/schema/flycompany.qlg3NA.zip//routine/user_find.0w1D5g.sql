create
    definer = root@localhost procedure user_find(in _login varchar(250))
select * from users where login = _login;

