create
    definer = root@localhost procedure client_remove(in id int)
begin
    start transaction;
    delete from client where id_client = id;
    commit;
end;

