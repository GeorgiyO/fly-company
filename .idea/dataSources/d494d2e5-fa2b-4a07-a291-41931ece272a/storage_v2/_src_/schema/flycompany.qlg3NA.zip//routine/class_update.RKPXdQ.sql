create
    definer = root@localhost procedure class_update(in name varchar(10), in plan int, in id int)
begin
    start transaction;
    update class
    set name_class = name,
        id_plan    = plan
    where id_class = id;
    select * from class where id_class = id;
    commit;
end;

