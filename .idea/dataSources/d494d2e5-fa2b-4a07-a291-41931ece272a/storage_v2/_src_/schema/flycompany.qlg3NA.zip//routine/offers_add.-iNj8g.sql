create
    definer = root@localhost procedure offers_add(in _place_id int, in _passenger_id int)
begin
    start transaction;
    insert into offers (place_id, passenger_id)
    values (_place_id, _passenger_id);
    select * from offers where id = last_insert_id();
    commit;
end;

