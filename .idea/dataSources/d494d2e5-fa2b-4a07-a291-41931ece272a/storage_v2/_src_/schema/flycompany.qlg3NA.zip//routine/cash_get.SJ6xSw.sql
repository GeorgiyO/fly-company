create
    definer = root@localhost procedure cash_get(in id int)
select *
from cash
where id_cash = id;

