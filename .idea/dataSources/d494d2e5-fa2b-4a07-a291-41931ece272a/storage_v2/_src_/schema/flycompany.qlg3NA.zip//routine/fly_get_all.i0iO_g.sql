create
    definer = root@localhost procedure fly_get_all()
select *
from fly;

