create
    definer = root@localhost procedure place_get_all()
select *
from place;

