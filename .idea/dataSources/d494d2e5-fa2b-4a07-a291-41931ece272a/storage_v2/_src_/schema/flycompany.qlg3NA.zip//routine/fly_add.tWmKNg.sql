create
    definer = root@localhost procedure fly_add(in number varchar(10), in _date date, in arrive int, in live int)
begin
    start transaction;
    insert into fly (number_fly, date_fly, id_arrive, id_live)
    values (number, _date, arrive, live);
    select * from fly where id_fly = last_insert_id();
    commit;
end;

