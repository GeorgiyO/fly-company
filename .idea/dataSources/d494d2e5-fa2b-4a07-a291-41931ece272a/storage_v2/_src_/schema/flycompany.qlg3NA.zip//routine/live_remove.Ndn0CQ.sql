create
    definer = root@localhost procedure live_remove(in id int)
begin
    start transaction;
    delete from live where id_live = id;
    commit;
end;

