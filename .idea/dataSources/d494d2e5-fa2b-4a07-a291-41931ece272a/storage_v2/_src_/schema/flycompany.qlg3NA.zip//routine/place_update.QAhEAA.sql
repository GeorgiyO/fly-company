create
    definer = root@localhost procedure place_update(in class int, in number varchar(4), in id int)
begin
    start transaction;
    update place
    set id_class     = class,
        number_place = number
    where id_place = id;
    select * from place where id_place = id;
    commit;
end;

