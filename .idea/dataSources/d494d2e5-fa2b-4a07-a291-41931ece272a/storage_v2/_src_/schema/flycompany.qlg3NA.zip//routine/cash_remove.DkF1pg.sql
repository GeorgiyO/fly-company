create
    definer = root@localhost procedure cash_remove(in id int)
begin
    start transaction;
    delete from cash where id_cash = id;
    commit;
end;

