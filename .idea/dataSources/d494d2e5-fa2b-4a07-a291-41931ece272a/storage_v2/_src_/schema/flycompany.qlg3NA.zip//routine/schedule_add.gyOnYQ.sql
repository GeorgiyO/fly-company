create
    definer = root@localhost procedure schedule_add(in _date datetime, in _price decimal, in _plane_id int,
                                                    in _from_addr_id int, in _to_addr_id int)
begin
    start transaction;
    insert into schedule (date, price, plane_id, from_addr_id, to_addr_id)
    values (_date, _price, _plane_id, _from_addr_id, _to_addr_id);
    select * from schedule where id = last_insert_id();
    commit;
end;

