create
    definer = root@localhost procedure places_remove(in _id int)
delete
from places
where id = _id;

