create
    definer = root@localhost procedure places_all()
select *
from places;

