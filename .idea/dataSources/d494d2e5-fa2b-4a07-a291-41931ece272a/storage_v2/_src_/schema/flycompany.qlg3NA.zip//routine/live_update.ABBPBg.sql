create
    definer = root@localhost procedure live_update(in name varchar(30), in address varchar(45), in id int)
begin
    start transaction;
    update live
    set name_live    = name,
        address_live = address
    where id_live = id;
    select * from live where id_live = id;
    commit;
end;

