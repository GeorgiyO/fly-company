create
    definer = root@localhost procedure worker_get(in id int)
select *
from worker
where id_worker = id;

