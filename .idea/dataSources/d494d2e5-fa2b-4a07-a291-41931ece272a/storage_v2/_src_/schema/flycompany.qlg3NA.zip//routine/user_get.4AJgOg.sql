create
    definer = root@localhost procedure user_get(in _id int)
select u.id, u.login, u.password, r.type
from users u
         join roles r on r.id = u.role_id
where u.id = _id;

