create
    definer = root@localhost procedure plan_add(in number varchar(10), in kind varchar(10), in worker int, in fly int)
begin
    start transaction;
    insert into plan (number_plan, kind_plan, id_worker, id_fly)
    values (number, kind, worker, fly);
    select * from plan where id_plan = last_insert_id();
    commit;
end;

