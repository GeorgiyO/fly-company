create
    definer = root@localhost procedure pilot_remove(in id int)
begin
    start transaction;
    delete from pilot where id_pilot = id;
    commit;
end;

